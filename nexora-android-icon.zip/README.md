# NEXORA AI, ícone do app Android (conceito 1, N fluido)

## Conteúdo
- res/drawable/ic_launcher_background.xml: fundo gradiente discreto (#1A0E33 → #0B0716)
- res/drawable/ic_launcher_foreground.xml: N com gradiente violeta → azul (dentro da zona segura de 66dp)
- res/drawable/ic_launcher_monochrome.xml: versão monocromática para o Android 13+ (ícones temáticos)
- res/mipmap-anydpi-v26/ic_launcher.xml e ic_launcher_round.xml: ícones adaptativos
- res/mipmap-{mdpi..xxxhdpi}/: PNGs para Android abaixo da API 26 (48 a 192 px)
- store/nexora_play_store_512.png: ícone de 512 px para a Google Play

## Como aplicar
1. Copie as pastas de res/ para app/src/main/res/ do projeto. Substitua os arquivos com o mesmo nome.
2. No AndroidManifest.xml, confirme:
   android:icon="@mipmap/ic_launcher"
   android:roundIcon="@mipmap/ic_launcher_round"
3. Se o projeto tiver ic_launcher.webp antigos nas pastas mipmap-*, remova-os. Caso contrário, o recurso antigo pode ter prioridade.
4. Gere um build e verifique o ícone no launcher e em Configurações > Papel de parede e estilo (Android 13+, ícones temáticos).
